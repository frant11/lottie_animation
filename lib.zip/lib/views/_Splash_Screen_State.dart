import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';

class SplashScreen1 extends StatefulWidget {
  const SplashScreen1({Key? key}) : super(key: key);

  @override
  State<SplashScreen1> createState() => _SplashScreen1State();
}

class _SplashScreen1State extends State<SplashScreen1>
    with TickerProviderStateMixin {
  late AnimationController _foodController;
  bool tigre = false;
  bool caraComiendo = false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _foodController = AnimationController(vsync: this);
    _foodController.addListener(() {
      if (_foodController.value > 0.7) ;
      _foodController.stop();
      tigre = true;
      setState(() {});
      Future.delayed(const Duration(seconds: 1), () {
        caraComiendo = true;
        setState(() {});
      });
    });
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    _foodController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 205, 68, 0),
      body: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.only(bottom: 200),
            child: AnimatedContainer(
              duration: const Duration(seconds: 1),
              decoration: BoxDecoration(
                color: Color.fromARGB(255, 238, 153, 114),
                boxShadow: const [
                  BoxShadow(
                    offset: Offset(3, 3),
                    blurRadius: 10,
                    spreadRadius: 2,
                    color: Colors.black26,
                  )
                ],
                borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(tigre ? 25.0 : 0.00),
                    bottomRight: Radius.circular(tigre ? 25.0 : 0.00)),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  AnimatedCrossFade(
                    firstChild: Lottie.asset('assets/tigre.json'),
                    secondChild: Lottie.asset(
                      'assets/cara.json',
                      controller: _foodController,
                      height: height / 2,
                      onLoaded: (composition) {
                        _foodController.duration = composition.duration;
                        _foodController.forward();
                      },
                    ),
                    crossFadeState: tigre
                        ? CrossFadeState.showFirst
                        : CrossFadeState.showSecond,
                    duration: const Duration(seconds: 3),
                  ),
                  Container(
                    child: Center(
                      child: AnimatedOpacity(
                        opacity: caraComiendo ? 1 : 0,
                        duration: const Duration(seconds: 1),
                        child: Text('Shunzi Food Express',
                            style: GoogleFonts.lobster(
                                textStyle: const TextStyle(
                              fontSize: 35.0,
                              color: Color.fromARGB(255, 184, 67, 0),
                              fontWeight: FontWeight.bold,
                            ))),
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
          //SizedBox(
          //height: 50,
          //),
          Visibility(visible: tigre, child: const _BottomPart()),
        ],
      ),
    );
  }
}

class _BottomPart extends StatelessWidget {
  const _BottomPart({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Padding(
        padding:
            const EdgeInsets.only(left: 40.0, right: 40.0, bottom: 85, top: 45),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Align(
              alignment: Alignment.center,
              child: Container(
                  height: 20.0,
                  width: 85.0,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      //shape: BoxShape.circle,
                      //border: Border.all(color: Colors.white, width: 2.0),
                      color: Colors.orangeAccent),
                  child: Text(
                    'Login',
                    style: TextStyle(
                      fontSize: 15,
                      color: Colors.white,
                    ),
                    textAlign: TextAlign.center,
                  )),
            ),
            const SizedBox(height: 15.0),
            Align(
              alignment: Alignment.center,
              child: Container(
                  height: 20.0,
                  width: 85.0,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.grey),
                  child: Text(
                    'Register',
                    style: TextStyle(
                      fontSize: 15,
                      color: Colors.white,
                    ),
                    textAlign: TextAlign.center,
                  )),
            ),
          ],
        ),
      ),
    );
  }
}
